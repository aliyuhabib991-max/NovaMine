# NOVA Mine JavaScript V1

Node.js + Express Telegram mining bot.

Flow:
`/start -> Register -> Pay 0.55 GRAM -> Submit TX hash -> Verify -> Mining`

Features:
- Registration before mining
- 0.55 GRAM TON payment
- TON transaction verification via TON Center API v3 when API key is configured
- Manual admin registration approval fallback
- Mining calculated from time (24-hour session)
- Daily reward
- Referrals
- TON wallet storage
- Claim requests + admin approval/rejection
- Admin commands

Admin ID is already set to `8829026396`.
Receiving wallet is already set to the supplied wallet.

IMPORTANT:
- Never put your BotFather token in GitHub or this chat.
- This MVP does not handle seed phrases/private keys.
- NOVA is not yet a real TON Jetton in this package; claims are manual/off-chain.
- Automatic registration verification checks transaction hash, destination and amount. A production system should add wallet ownership verification.
- The included JSON storage is for testing. Use persistent storage/database for production.

Render:
1. Create a Web Service.
2. Build command: `npm install`
3. Start command: `npm start`
4. Add all variables from `.env.example`.
5. After deployment, set Telegram webhook:
`https://api.telegram.org/botYOUR_TOKEN/setWebhook?url=https://YOUR-SERVICE.onrender.com/webhook/YOUR_WEBHOOK_SECRET`

Admin:
`/stats`
`/withdrawals`
`/approve ID TX_HASH`
`/reject ID reason`
`/approve_reg USER_ID TX_HASH`
`/id`
